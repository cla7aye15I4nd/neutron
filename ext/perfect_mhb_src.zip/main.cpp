#include "term.hpp"

term sys;
int main() {
    //freopen("all.in", "r", stdin);
    sys.run();
    return 0;
}
